CONFIG_FILENAME = "vs_server_manager_config.json"
# The actual VS server config we will be editing for World Gen
SERVER_CONFIG_FILENAME = "serverconfig.json"
# Default folder name for bundled client mods
MOD_EXPORTS_DIR = "ModExports"